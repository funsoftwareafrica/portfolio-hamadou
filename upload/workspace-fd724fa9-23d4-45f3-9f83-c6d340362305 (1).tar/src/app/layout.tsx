import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { ThemeProvider } from "next-themes";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Hamadou Ali Abdoul-Latif | Développeur Full-Stack Web & Mobile",
  description:
    "Développeur Full-Stack avec 5+ ans d'expérience. Sites web, e-commerce, SaaS, applications mobiles. Expertise Fintech & Paiement. Disponible freelance remote.",
  keywords: [
    "développeur full-stack",
    "développeur web",
    "développeur freelance",
    "création site web",
    "e-commerce",
    "application mobile",
    "SaaS",
    "React",
    "Next.js",
    "Node.js",
    "TypeScript",
    "fintech",
    "paiement",
    "Hamadou",
    "Abdoul-Latif",
  ],
  authors: [{ name: "Hamadou Ali Abdoul-Latif" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Hamadou Ali Abdoul-Latif | Développeur Full-Stack Web & Mobile",
    description:
      "Sites web, e-commerce, SaaS, applications mobiles et solutions Fintech sur mesure. Disponible freelance remote.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Hamadou Ali Abdoul-Latif | Développeur Full-Stack Web & Mobile",
    description:
      "Sites web, e-commerce, SaaS, applications mobiles. Expertise Fintech. Disponible freelance.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
