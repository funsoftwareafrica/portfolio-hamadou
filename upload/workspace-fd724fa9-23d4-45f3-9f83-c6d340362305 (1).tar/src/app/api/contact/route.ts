import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, phone, subject, message, budget } = body

    if (!name || !email || !message || !subject) {
      return NextResponse.json(
        { error: 'Les champs nom, email, sujet et message sont requis.' },
        { status: 400 }
      )
    }

    const lead = await db.lead.create({
      data: {
        name,
        email,
        phone: phone || null,
        subject,
        message,
        budget: budget || null,
      },
    })

    return NextResponse.json({ success: true, id: lead.id })
  } catch (error) {
    console.error('Contact form error:', error)
    return NextResponse.json(
      { error: 'Erreur interne du serveur.' },
      { status: 500 }
    )
  }
}
